import Header from './components/Header';
import Main from './components/Main';
import Basket from './components/Basket';
import data from './data';
import { useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';

const useStyles = makeStyles((theme) => ({
  root: {
    '& > *': {
      margin: theme.spacing(1),
      width: '25ch',
    },
  },
}));
function App() {
  const classes = useStyles();

  const { products } = data;
  const [cartItems, setCartItems] = useState([]);
  const [myProducts,setMyProducts]=useState(products);
  const onAdd = (product) => {
    const exist = cartItems.find((x) => x.id === product.id);
    if (exist) {
      setCartItems(
        cartItems.map((x) =>
          x.id === product.id ? { ...exist, qty: exist.qty + 1 } : x
        )
      );
    } else {
      setCartItems([...cartItems, { ...product, qty: 1 }]);
    }
  };
  const onRemove = (product) => {
    const exist = cartItems.find((x) => x.id === product.id);
    if (exist.qty === 1) {
      setCartItems(cartItems.filter((x) => x.id !== product.id));
    } else {
      setCartItems(
        cartItems.map((x) =>
          x.id === product.id ? { ...exist, qty: exist.qty - 1 } : x
        )
      );
    }
  };
  const onKeyUp=(event)=>{
    if(!event.target.value){
      setMyProducts(products);
      return;
    }

    setMyProducts(products.filter(function(x) {
      return  x.name.toLowerCase() === event.target.value.toLowerCase()
      }));
  }

  return (
    <div className="App">
      <Header countCartItems={cartItems.length}></Header>
      <form className={classes.root} noValidate autoComplete="off">
      <TextField id="outlined-basic" label="Search" variant="outlined"onKeyUp={(event) => onKeyUp(event)}/>
     </form>
      <div className="row">
        <Main products={myProducts} onAdd={onAdd}></Main>
        <Basket
          cartItems={cartItems}
          onAdd={onAdd}
          onRemove={onRemove}
        ></Basket>
      </div>
    </div>
  );
}

export default App;
